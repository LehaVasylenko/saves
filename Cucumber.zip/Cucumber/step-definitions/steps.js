import { Given, When, Then } from '@wdio/cucumber-framework';

Given('User is located on the main page of saucedemo website' , async function () {
    await browser.url('https://www.saucedemo.com/');
    await $('#login-button').waitForDisplayed();
});

When('User clicks the "Login" button', async function () {
  const button = await $('#login-button');
  await button.waitForDisplayed();
  button.click();
});

Then('User should see "Epic sadface: Username is required" error message', async function () {
  const sadText = await $('//h3[@data-test="error"]').getText();
  const expectedText = "Epic sadface: Username is required";
  expect(sadText).to.equal(expectedText);
});