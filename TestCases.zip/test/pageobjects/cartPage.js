import { $ } from '@wdio/globals'
import Page from './page.js'

/**
 * sub page containing specific selectors and methods for a specific page
 */
class CartPage extends Page {
    /**
     * define selectors using getter methods
     */
     //header features
     get headerContainer () {
        return $('#header_container');
    }
    get primaryHeader () {
        return $('//div[@class="primary_header"]');
    }
    get menuButtonContainer () {
        return $('#menu_button_container');
    }
    get bmBurgerButton () {
        return $('//div[@class="bm-burger-button"]');
    }
    get burgerButton () {
        return $('#react-burger-menu-btn');
    }
    get bmIcon () {
        return $('//img[@class="bm-icon"]');
    }
    get headerLabel () {
        return $('//div[@class="header_label"]');
    }
    get appLogo () {
        return $('//div[@class="app_logo"]');
    }
    get shoppingCartContainer () {
        return $('#shopping_cart_container');
    }
    get cartLink () {
        return $('//a[@class="shopping_cart_link"]');
    }
    get headerSecondaryContainer () {
        return $('//div[@class="header_secondary_container"]');
    }
    get productsTitle () {
        return $('//span[@class="title"]');
    }
    
    get burgMen () {
        return $('//div[@class="bm-menu-wrap"]');
    }

    get burgNav () {
        return $('//nav[@class="bm-item-list"]');
    }

    get menItem1 () {
        return $('#inventory_sidebar_link');
    }

    get menItem2 () {
        return $('#about_sidebar_link')
    }

    get menItem3 () {
        return $('#logout_sidebar_link')
    }

    get menItem4 () {
        return $('#reset_sidebar_link')
    }

    async burgerMenuDisplayedOk () {
        await expect(this.burgMen.isDisplayed());
        await expect(this.burgNav.isDisplayed());
        await expect(this.menItem1.isDisplayed());
        await expect(this.menItem2.isDisplayed());
        await expect(this.menItem3.isDisplayed());
        await expect(this.menItem4.isDisplayed());
    }

    async headerIsDisplayedOk () {
        await expect(this.headerContainer.isDisplayed());
        await expect(this.primaryHeader.isDisplayed());
        await expect(this.menuButtonContainer.isDisplayed());
        await expect(this.bmBurgerButton.isDisplayed());
        await expect(this.burgerButton.isDisplayed());
        await expect(this.bmIcon.isDisplayed());
        await expect(this.headerLabel.isDisplayed());
        await expect(this.appLogo.isDisplayed());
        await expect(this.shoppingCartContainer.isDisplayed());
        await expect(this.cartLink.isDisplayed());
        await expect(this.headerSecondaryContainer.isDisplayed());
        await expect(this.productsTitle.isDisplayed());
    }    

    //footer features
    get footer (){
        return $('//footer')
    }
    get social (){
        return $('//ul[@class="social"]')
    }
    get liTwitter (){
        return $('//li[@class="social_twitter"]')
    }
    get aTwitter (){
        return $('//a[text()="Twitter"]')
    }
    get liFacebook (){
        return $('//li[@class="social_facebook"]')
    }
    get aFacebook (){
        return $('//a[text()="Facebook"]')
    }
    get liLinkedin (){
        return $('//li[@class="social_linkedin"]')
    }
    get aLinkedin (){
        return $('//a[text()="LinkedIn"]')
    }
    get getCopy (){
        return $('//div[@class="footer_copy"]')
    }
    get textCopy (){
        return $('//div[@class="footer_copy"]')
    }
    
    async footerIsDisplayedOK () {
        await expect(this.footer.isDisplayed());
        await expect(this.social.isDisplayed());
        await expect(this.liTwitter.isDisplayed());
        await expect(this.aTwitter.isDisplayed());
        await expect(this.liFacebook.isDisplayed());
        await expect(this.aFacebook.isDisplayed());
        await expect(this.liLinkedin.isDisplayed());
        await expect(this.aLinkedin.isDisplayed());
        await expect(this.getCopy.isDisplayed());
        await expect(this.textCopy.isDisplayed());
    }

    get cartList() {
        return $('//div[@class="cart_list"]');
    }

    get qtyLabel () {
        return $('//div[@class="cart_quantity_label"]');
    }

    get descLabel () {
        return $('//div[@class="cart_desc_label"]');
    }

    get cartFooter () {
        return $('//div[@class="cart_footer"]');
    }

    get btnContShopping () {
        return $('#continue-shopping');
    }

    get imgBack () {
        return $('//img[@class="back-image"]');
    }

    get btnCheckout () {
        return $('#checkout');
    }

    checkoutClick () {
        return this.btnCheckout.click();
    }

    async cartDisplayedOk () {
        await expect(this.footerIsDisplayedOK());
        await expect(this.headerIsDisplayedOk());
        await expect(this.cartList.isDisplayed());
        await expect(this.qtyLabel.isDisplayed());
        await expect(this.descLabel.isDisplayed());
        await expect(this.cartFooter.isDisplayed());
        await expect(this.btnContShopping.isDisplayed());
        await expect(this.imgBack.isDisplayed());
        await expect(this.btnCheckout.isDisplayed());

    }

    //items features
    get cartItem () {
        return $$('//div[@class="cart_item"]');
    }
    get cartQnt () {
        return $$('//div[@class="cart_quantity"]');
    }
    get cartItemLabel () {
        return $$('//div[@class="cart_item_label"]');
    }
    
    get itemDescription () {
        return $$('//div[@class="inventory_item_desc"]');
    }
    get itemPriceBar () {
        return $$('//div[@class="item_pricebar"]');
    }
    get itemPrice () {
        return $$('//div[@class="inventory_item_price"]');
    }
    get removeButton () {
        return $$('//button[@class="btn btn_secondary btn_small cart_button"]');
    }
    
    async compareItems (innerText) {

        let flag = false;

            const cartElements = await $$('//div[@class="cart_item"]');
            for (let i = 1; i <= cartElements.length; i++) {
                const text = await cartElements[i].getText();
                if (text.match(innerText) != 0) {
                    flag = true;
                    break;
                }
            }
        return flag;
    }

    async itemsIsDisplayedOk () {
        for (let i = 1; i<=this.cartItem.lengt; i++)
        {
            await expect(this.cartItem[i].isDisplayed());
            await expect(this.cartQnt[i].isDisplayed());
            await expect(this.cartItemLabel[i].isDisplayed());
            await expect(this.itemId[i].isDisplayed());
            await expect(this.itemDescription[i].isDisplayed());
            await expect(this.itemDesc[i].isDisplayed());
            await expect(this.itemPriceBar[i].isDisplayed());
            await expect(this.itemPrice[i].isDisplayed());
            await expect(this.removeButton[i].isDisplayed());
        }
    }

}
export default new CartPage();