import { $ } from '@wdio/globals'
import Page from './page.js'

/**
 * sub page containing specific selectors and methods for a specific page
 */
class ConfirmationPage extends Page {

    get headerContainer () {
        return $('#header_container');
    }
    get primaryHeader () {
        return $('//div[@class="primary_header"]');
    }
    get menuButtonContainer () {
        return $('#menu_button_container');
    }
    get bmBurgerButton () {
        return $('//div[@class="bm-burger-button"]');
    }
    get burgerButton () {
        return $('#react-burger-menu-btn');
    }
    get bmIcon () {
        return $('//img[@class="bm-icon"]');
    }
    get headerLabel () {
        return $('//div[@class="header_label"]');
    }
    get appLogo () {
        return $('//div[@class="app_logo"]');
    }
    get shoppingCartContainer () {
        return $('#shopping_cart_container');
    }
    get cartLink () {
        return $('//a[@class="shopping_cart_link"]');
    }
    get headerSecondaryContainer () {
        return $('//div[@class="header_secondary_container"]');
    }
    get productsTitle () {
        return $('//span[@class="title"]');
    }
    
    get burgMen () {
        return $('//div[@class="bm-menu-wrap"]');
    }

    get burgNav () {
        return $('//nav[@class="bm-item-list"]');
    }

    get menItem1 () {
        return $('#inventory_sidebar_link');
    }

    get menItem2 () {
        return $('#about_sidebar_link')
    }

    get menItem3 () {
        return $('#logout_sidebar_link')
    }

    get menItem4 () {
        return $('#reset_sidebar_link')
    }

    async burgerMenuDisplayedOk () {
        await expect(this.burgMen.isDisplayed());
        await expect(this.burgNav.isDisplayed());
        await expect(this.menItem1.isDisplayed());
        await expect(this.menItem2.isDisplayed());
        await expect(this.menItem3.isDisplayed());
        await expect(this.menItem4.isDisplayed());
    }

    async burgerMenuGet () {
        await this.burgerButton.click();        
    }

    async logOut () {
        await this.menItem3.click();
    }
    async cartOpen () {
        await this.cartLink.click();
    }
    
    async headerIsDisplayedOk () {
        await expect(this.headerContainer.isDisplayed());
        await expect(this.primaryHeader.isDisplayed());
        await expect(this.menuButtonContainer.isDisplayed());
        await expect(this.bmBurgerButton.isDisplayed());
        await expect(this.burgerButton.isDisplayed());
        await expect(this.bmIcon.isDisplayed());
        await expect(this.headerLabel.isDisplayed());
        await expect(this.appLogo.isDisplayed());
        await expect(this.shoppingCartContainer.isDisplayed());
        await expect(this.cartLink.isDisplayed());
        await expect(this.headerSecondaryContainer.isDisplayed());
        await expect(this.productsTitle.isDisplayed());
    }    

    //footer features
    get footer (){
        return $('//footer')
    }
    get social (){
        return $('//ul[@class="social"]')
    }
    get liTwitter (){
        return $('//li[@class="social_twitter"]')
    }
    get aTwitter (){
        return $('//a[text()="Twitter"]')
    }
    get liFacebook (){
        return $('//li[@class="social_facebook"]')
    }
    get aFacebook (){
        return $('//a[text()="Facebook"]')
    }
    get liLinkedin (){
        return $('//li[@class="social_linkedin"]')
    }
    get aLinkedin (){
        return $('//a[text()="LinkedIn"]')
    }
    get getCopy (){
        return $('//div[@class="footer_copy"]')
    }
    get textCopy (){
        return $('//div[@class="footer_copy"]')
    }
    
    async footerIsDisplayedOK () {
        await expect(this.footer.isDisplayed());
        await expect(this.social.isDisplayed());
        await expect(this.liTwitter.isDisplayed());
        await expect(this.aTwitter.isDisplayed());
        await expect(this.liFacebook.isDisplayed());
        await expect(this.aFacebook.isDisplayed());
        await expect(this.liLinkedin.isDisplayed());
        await expect(this.aLinkedin.isDisplayed());
        await expect(this.getCopy.isDisplayed());
        await expect(this.textCopy.isDisplayed());
    }

    //confirmation items
    get checkoutSummaryContainer () {
        return $('#checkout_summary_container');
    }

    get cartList () {
        return $('//div[@class="cart_list"]');
    }

    get cartQtyLabel () {
        return $('//div[@class="cart_quantity_label"]');
    }

    get cartDescriptionLabel () {
        return $('//div[@class="cart_desc_label"]');
    }

    get cartItem () {
        return $$('//div[@class="cart_item"]');
    }

    get cartItemSize () {
        return this.cartItem.length;
    }

    get cartQty () {
        return $$('//div[@class="cart_quantity"]');
    }

    get cartItemLabel () {
        return $$('//div[@class="cart_item_label"]');
    }

    get itemDescription () {
        return $$('//div[@class="inventory_item_desc"]');
    }

    get itemPricebar () {
        return $$('//div[@class="item_pricebar"]');
    }

    get itemPrice () {
        return $$('//div[@class="inventory_item_price"]');
    }

    get summaryInfo () {
        return $('//div[@class="summary_info"]');
    }

    get summaryInfoLabel () {
        return $$('//div[@class="summary_info_label"]');
    }

    get summaryValueLabel () {
        return $$('//div[@class="summary_value_label"]');
    }

    get summarySubtotalLabel () {
        return $('//div[@class="summary_subtotal_label"]');
    }

    get summaryTaxLabel () {
        return $('//div[@class="summary_tax_label"]');
    }

    get summarySummary () {
        return $('summary_info_label summary_total_label');
    }

    get cartFooter () {
        return $('//div[@class="cart_footer"]');
    }

    get cancelButton () {
        return $('#cancel');
    }

    get finishButton () {
        return $('#finish');
    }

    async finishButtonClick () {
        await this.finishButton.scrollIntoView();
        await this.finishButton.click();
    }

    async confirmationIsDisplayedOk() {
        this.headerIsDisplayedOk();
        this.footerIsDisplayedOK();
        await expect(this.checkoutSummaryContainer.isDisplayed());
        await expect(this.cartList.isDisplayed());
        await expect(this.cartQtyLabel.isDisplayed());
        await expect(this.cartDescriptionLabel.isDisplayed());
        await expect(this.itemDescription.isDisplayed());
        await expect(this.itemPricebar.isDisplayed());
        await expect(this.itemPrice.isDisplayed());
        await expect(this.summaryInfo.isDisplayed());
        await expect(this.summaryInfoLabel.isDisplayed());
        await expect(this.summaryValueLabel.isDisplayed());
        await expect(this.summarySubtotalLabel.isDisplayed());
        await expect(this.summaryTaxLabel.isDisplayed());
        await expect(this.summarySummary.isDisplayed());
        await expect(this.cartFooter.isDisplayed());
        await expect(this.cancelButton.isDisplayed());
        await expect(this.finishButton.isDisplayed());
        
    }
       
    open () {
     
    }
}
export default new ConfirmationPage();
