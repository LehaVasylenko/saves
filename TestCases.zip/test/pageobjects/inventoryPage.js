import page from './page.js'
import { browser } from '@wdio/globals'


class inventoryPage extends page {
 //header features
 get headerContainer () {
    return $('#header_container');
}
get primaryHeader () {
    return $('//div[@class="primary_header"]');
}
get menuButtonContainer () {
    return $('#menu_button_container');
}
get bmBurgerButton () {
    return $('//div[@class="bm-burger-button"]');
}
get burgerButton () {
    return $('#react-burger-menu-btn');
}
get bmIcon () {
    return $('//img[@class="bm-icon"]');
}
get headerLabel () {
    return $('//div[@class="header_label"]');
}
get appLogo () {
    return $('//div[@class="app_logo"]');
}
get shoppingCartContainer () {
    return $('#shopping_cart_container');
}
get cartLink () {
    return $('//a[@class="shopping_cart_link"]');
}
get headerSecondaryContainer () {
    return $('//div[@class="header_secondary_container"]');
}
get productsTitle () {
    return $('//span[@class="title"]');
}

get rightComponent () {
    return $('//div[@class="right_component"]');
}

get selectContainer () {
    return $('//span[@class="select_container"]');
}

get sortContainer () {
    return $('//select[@class="product_sort_container"]');
}

get burgMen () {
    return $('//div[@class="bm-menu-wrap"]');
}

get burgNav () {
    return $('//nav[@class="bm-item-list"]');
}

get menItem1 () {
    return $('#inventory_sidebar_link');
}

get menItem2 () {
    return $('#about_sidebar_link')
}

get menItem3 () {
    return $('#logout_sidebar_link')
}

get menItem4 () {
    return $('#reset_sidebar_link')
}

async burgerMenuDisplayedOk () {
    await expect(this.burgMen.isDisplayed());
    await expect(this.burgNav.isDisplayed());
    await expect(this.menItem1.isDisplayed());
    await expect(this.menItem2.isDisplayed());
    await expect(this.menItem3.isDisplayed());
    await expect(this.menItem4.isDisplayed());
}

async burgerMenuGet () {
    return await this.burgerButton.click();        
}

async logOut () {
    return await this.menItem3.click();
}
async cartOpen () {
    return await this.cartLink.click();
}

async headerIsDisplayedOk () {
    await expect(this.headerContainer.isDisplayed());
    await expect(this.primaryHeader.isDisplayed());
    await expect(this.menuButtonContainer.isDisplayed());
    await expect(this.bmBurgerButton.isDisplayed());
    await expect(this.burgerButton.isDisplayed());
    await expect(this.bmIcon.isDisplayed());
    await expect(this.headerLabel.isDisplayed());
    await expect(this.appLogo.isDisplayed());
    await expect(this.shoppingCartContainer.isDisplayed());
    await expect(this.cartLink.isDisplayed());
    await expect(this.headerSecondaryContainer.isDisplayed());
    await expect(this.productsTitle.isDisplayed());
}    

//footer features
get footer (){
    return $('//footer')
}
get social (){
    return $('//ul[@class="social"]')
}
get liTwitter (){
    return $('//li[@class="social_twitter"]')
}
get aTwitter (){
    return $('//a[text()="Twitter"]')
}
get liFacebook (){
    return $('//li[@class="social_facebook"]')
}
get aFacebook (){
    return $('//a[text()="Facebook"]')
}
get liLinkedin (){
    return $('//li[@class="social_linkedin"]')
}
get aLinkedin (){
    return $('//a[text()="LinkedIn"]')
}
get getCopy (){
    return $('//div[@class="footer_copy"]')
}
get textCopy (){
    return $('//div[@class="footer_copy"]')
}

async footerIsDisplayedOK () {
    await expect(this.footer.isDisplayed());
    await expect(this.social.isDisplayed());
    await expect(this.liTwitter.isDisplayed());
    await expect(this.aTwitter.isDisplayed());
    await expect(this.liFacebook.isDisplayed());
    await expect(this.aFacebook.isDisplayed());
    await expect(this.liLinkedin.isDisplayed());
    await expect(this.aLinkedin.isDisplayed());
    await expect(this.getCopy.isDisplayed());
    await expect(this.textCopy.isDisplayed());
}

async scrollToFooter() {
    return await this.footer.scrollIntoView();
}

async facebookClick() {
    return await this.aFacebook.click();
}

async twitterClick () {
    return await this.aTwitter.click();
}

async linkedinClick () {
    return await this.aLinkedin.click();
}

get inventoryContainer () {
    return $('//div[@class = "inventory_container"]');
}

get inventoryList () {
    return $('//div[@class = "inventory_list"]');
}

get inventoryItems () {
    return $$('//div[@class = "inventory_item"]');
}

get inventoryItemImgs () {
    return $$('//div[@class = "inventory_item_img"]');
}

get inventoryItemDescs () {
    return $$('//div[@class = "inventory_item_description"]');
}

get inventoryItemLabels () {
    return $$('//div[@class = "inventory_item_label"]');
}

get inventoryItemNames () {
    return $$('//div[@class = "inventory_item_name"]');
}

get itemsDescs () {
    return $$('//div[@class = "inventory_item_desc"]');
}

get itemsPricebars () {
    return $$('//div[@class = "pricebar"]');
}

get itemsPrices () {
    return $$('//div[@class = "inventory_item_price"]');
}

get itemsButtons () {
    return $$('//button[@class = "btn btn_primary btn_small btn_inventory"]');
}

async sortAndCheckItems (i) {

    //I don't know WHY, but ".selectByIndex(i)"" doesn't operate with select container
    //so I implemented this
    
    await $('(//select[@class="product_sort_container"]/option)['+i+']').click();
    
    // Wait
    await browser.waitUntil( async () => (await $('(//div[@class="inventory_item_price"])[6]').isDisplayed(),
        { timeout: 10000, timeoutMsg: 'Last element of the page not displayed within 10 seconds' }));
  
      // Get product elements
      const productLabels = await $$('//div[@class="inventory_item_name"]');
      const productPrices = await $$('//div[@class="inventory_item_price"]');
  
      // Initialize an array to store the inner text of each product
      const itemLabels = [];
      const itemPrices = [];
  
      // Loop through each product Label and retrieve its inner text
      for (let j = 0; j < productLabels.length; j++) {
        const innerText = await productLabels[j].getText();
        itemLabels.push(innerText);
      }

      // Loop through each product price and retrieve its inner text as float number
      for (let j = 0; j < productPrices.length; j++) {
        const innerText1 = await productPrices[j].getText();
        const priceWithoutDollar = innerText1.replace('$', '');
        const priceAsFloat = parseFloat(priceWithoutDollar);
        itemPrices.push(priceAsFloat);
      }
    
    let isSorted = true;

    switch (i) {
        case 1:
            //A-Z
            for (let j = 1; j < itemLabels.length; j++) {
                if (itemLabels[j].localeCompare(itemLabels[j - 1]) < 0) {
                  isSorted = false;
                  break;
                }
            }
            break;
        case 2:
            //Z-A
            for (let j = 1; j < itemLabels.length; j++) {
                if (itemLabels[j].localeCompare(itemLabels[j - 1]) > 0) {
                  isSorted = false;
                  break;
                }
            }
            break;
        case 3:
            //Price: lo-hi
            for (let j = 1; j < itemPrices.length; j++) {
                if (itemPrices[j] < itemPrices[j - 1]) {
                  isSorted = false;
                  break;
                }
            }
            break;
        case 4:
            //Price: hi-lo
            for (let j = 1; j < itemPrices.length; j++) {
                if (itemPrices[j] > itemPrices[j - 1]) {
                  isSorted = false;
                  break;
                }
            }
            break;
        default: isSorted = false;
    }
    return isSorted;
}

async inventoryPageIsDisplayedOK () {
    await browser.waitUntil(() => {return this.footer.isDisplayed();},15000, 'Footer gone away...');
    this.footerIsDisplayedOK();
    this.headerIsDisplayedOk();
    await expect(this.inventoryContainer.isDisplayed());
    await expect(this.inventoryList.isDisplayed());
    for (let i = 1; i <= this.itemsButtons.length; i++) 
    {
        await expect(this.inventoryItems.isDisplayed());
        await expect(this.inventoryItemImgs.isDisplayed());
        await expect(this.inventoryItemDescs.isDisplayed());
        await expect(this.inventoryItemLabels.isDisplayed());
        await expect(this.inventoryItemNames.isDisplayed());
        await expect(this.itemsDescs.isDisplayed());
        await expect(this.itemsPricebars.isDisplayed());
        await expect(this.itemsPrices.isDisplayed());
        await expect(this.itemsButtons.isDisplayed());
    }
}

addToCart (i) {
    return this.itemsButtons[i].click();
}

async cartNotEmpty () {

    await browser.waitUntil(() => {return $('//span[@class="shopping_cart_badge"]').isDisplayed();},15000, 'OOOPS!.. No cart bange...');
    const badge = await $('//span[@class="shopping_cart_badge"]');
    const innerText = await badge.getText();

    if (badge && innerText) {
        return true;
    } else {
        return false;
    }
}

async checkUrl (url_social) {
    
    const handles = await browser.getWindowHandles();
    if (handles.length < 2) {
        throw new Error('Expected at least two window handles, but found less.');
      }

    await browser.switchToWindow(handles[1]);
    await expect(browser).toHaveUrl(url_social);
    await browser.closeWindow();
    await browser.switchToWindow(handles[0]);
    console.log('!!!!!!'+url_social);
}

open () {
     
}
}
export default new inventoryPage();
