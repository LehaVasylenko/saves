import { $ } from '@wdio/globals'
import Page from './page.js'

/**
 * sub page containing specific selectors and methods for a specific page
 */
class LoginPage extends Page {
    /**
     * define selectors using getter methods
     */
    get inputUsername () {
        return $('#user-name');
    }

    get inputPassword () {
        return $('#password');
    }

    get btnSubmit () {
        return $('input[type="submit"]');
    }
    
    //errors
    get inputUsernameError () {
        return $('(//input[@class="input_error form_input error"])[1]');
    }

    get inputPasswordError () {
        return $('(//input[@class="input_error form_input error"])[2]');
    }

    get epicSadFaceButton () {
        return $('//button["Epic sadface: Username is required"]');
    }

    async wrongLogin () {
        await browser.waitUntil(() => {return this.epicSadFaceButton.isDisplayed();},15000, 'something wrong!!!!');
        await this.inputPasswordError.isDisplayed();
        await this.inputUsernameError.isDisplayed();
        await this.epicSadFaceButton.isDisplayed();
    }

    loginFielText () {
        return this.inputUsername.getText();
    }

    passwordFielText () {
        return this.inputPassword.getText();
    }

    loginPageEmpty () {
        if (this.inputUsername.getText() ==='' && this.inputPassword.getText() ==='') {
            return true;
        } else { 
            return false
        }
    }
    /**
     * a method to encapsule automation code to interact with the page
     * e.g. to login using username and password
     */
    async login (username, password) {
        await this.inputUsername.setValue(username);
        await this.inputPassword.setValue(password);
        await this.btnSubmit.click();
    }

    /**
     * overwrite specific options to adapt it to page object
     */
    open () {
        return super.open('');
    }
}

export default new LoginPage();