import { $ } from '@wdio/globals'
import Page from './page.js'

/**
 * sub page containing specific selectors and methods for a specific page
 */
class FinalPage extends Page {

    get headerContainer () {
        return $('#header_container');
    }
    get primaryHeader () {
        return $('//div[@class="primary_header"]');
    }
    get menuButtonContainer () {
        return $('#menu_button_container');
    }
    get bmBurgerButton () {
        return $('//div[@class="bm-burger-button"]');
    }
    get burgerButton () {
        return $('#react-burger-menu-btn');
    }
    get bmIcon () {
        return $('//img[@class="bm-icon"]');
    }
    get headerLabel () {
        return $('//div[@class="header_label"]');
    }
    get appLogo () {
        return $('//div[@class="app_logo"]');
    }
    get shoppingCartContainer () {
        return $('#shopping_cart_container');
    }
    get cartLink () {
        return $('//a[@class="shopping_cart_link"]');
    }
    get headerSecondaryContainer () {
        return $('//div[@class="header_secondary_container"]');
    }
    get productsTitle () {
        return $('//span[@class="title"]');
    }
    
    get burgMen () {
        return $('//div[@class="bm-menu-wrap"]');
    }

    get burgNav () {
        return $('//nav[@class="bm-item-list"]');
    }

    get menItem1 () {
        return $('#inventory_sidebar_link');
    }

    get menItem2 () {
        return $('#about_sidebar_link')
    }

    get menItem3 () {
        return $('#logout_sidebar_link')
    }

    get menItem4 () {
        return $('#reset_sidebar_link')
    }

    async burgerMenuDisplayedOk () {
        await expect(this.burgMen.isDisplayed());
        await expect(this.burgNav.isDisplayed());
        await expect(this.menItem1.isDisplayed());
        await expect(this.menItem2.isDisplayed());
        await expect(this.menItem3.isDisplayed());
        await expect(this.menItem4.isDisplayed());
    }

    async headerIsDisplayedOk () {
        await expect(this.headerContainer.isDisplayed());
        await expect(this.primaryHeader.isDisplayed());
        await expect(this.menuButtonContainer.isDisplayed());
        await expect(this.bmBurgerButton.isDisplayed());
        await expect(this.burgerButton.isDisplayed());
        await expect(this.bmIcon.isDisplayed());
        await expect(this.headerLabel.isDisplayed());
        await expect(this.appLogo.isDisplayed());
        await expect(this.shoppingCartContainer.isDisplayed());
        await expect(this.cartLink.isDisplayed());
        await expect(this.headerSecondaryContainer.isDisplayed());
        await expect(this.productsTitle.isDisplayed());
    }    

    //footer features
    get footer (){
        return $('//footer')
    }
    get social (){
        return $('//ul[@class="social"]')
    }
    get liTwitter (){
        return $('//li[@class="social_twitter"]')
    }
    get aTwitter (){
        return $('//a[text()="Twitter"]')
    }
    get liFacebook (){
        return $('//li[@class="social_facebook"]')
    }
    get aFacebook (){
        return $('//a[text()="Facebook"]')
    }
    get liLinkedin (){
        return $('//li[@class="social_linkedin"]')
    }
    get aLinkedin (){
        return $('//a[text()="LinkedIn"]')
    }
    get getCopy (){
        return $('//div[@class="footer_copy"]')
    }
    get textCopy (){
        return $('//div[@class="footer_copy"]')
    }
    
    async footerIsDisplayedOK () {
        await expect(this.footer.isDisplayed());
        await expect(this.social.isDisplayed());
        await expect(this.liTwitter.isDisplayed());
        await expect(this.aTwitter.isDisplayed());
        await expect(this.liFacebook.isDisplayed());
        await expect(this.aFacebook.isDisplayed());
        await expect(this.liLinkedin.isDisplayed());
        await expect(this.aLinkedin.isDisplayed());
        await expect(this.getCopy.isDisplayed());
        await expect(this.textCopy.isDisplayed());
    }

    //final page features

        get completeContainer () {
            return $('#checkout_complete_container');
        }

        get completeImg () {
            return $('//img[@alt="Pony Express"]');
        }

        get h2Text () {
            return $("//h2[text()='Thank you for your order!']");
        }

        get completeText () {
            return $('//div[@class="complete-text"]');
        }

        get backButton () {
            return $('#back-to-products');
        }

         async backButtonClick() {
            return await this.backButton.click();
        }

        async finalIsDisplayedOk() 
        {
            this.headerIsDisplayedOk();
            this.footerIsDisplayedOK();
            await expect(this.completeContainer.isDisplayed());
            await expect(this.completeImg.isDisplayed());
            await expect(this.h2Text.isDisplayed());
            await expect(this.completeText.isDisplayed());
            await expect(this.backButton.isDisplayed());
        }

        open () {
        
        }
}
export default new FinalPage();