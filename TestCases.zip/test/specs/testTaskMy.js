import LoginPage from '../pageobjects/login.page.js'
import { browser } from '@wdio/globals'
import inventoryPage from '../pageobjects/inventoryPage.js'
import cartPage from '../pageobjects/cartPage.js'
import checkoutPage from '../pageobjects/checkoutPage.js'
import confirmationPage from '../pageobjects/confirmationPage.js'
import finalPage from '../pageobjects/finalPage.js'

const loginUrl = 'https://www.saucedemo.com/';
const inventoryUrl = 'https://www.saucedemo.com/inventory.html';
const cartUrl = 'https://www.saucedemo.com/cart.html';
const checkoutUrl = 'https://www.saucedemo.com/checkout-step-one.html';
const confirmationUrl = 'https://www.saucedemo.com/checkout-step-two.html';
const finalUrl = 'https://www.saucedemo.com/checkout-complete.html';
const facebookUrl = 'https://www.facebook.com/saucelabs';
const twitterUrl = 'https://twitter.com/saucelabs';
const linkedinUrl = 'https://www.linkedin.com/company/sauce-labs/';

const validLogin = 'standard_user';
const validPassword = 'secret_sauce';
const inValidLogin = 'not_standard_user';
const inValidPassword = 'not_secret_sauce';

function start (log, pass) {
    LoginPage.open();
    LoginPage.login(log,pass)    
}

describe('My test task', () => {
    xit('Test case ID: 1 ', async () => {
        
        //browser start
        start (validLogin,validPassword);
          
        //expect proper url
        await expect(browser).toHaveUrl(inventoryUrl);

        //check if everything OK
        inventoryPage.inventoryPageIsDisplayedOK();
    })

    xit('Test case ID: 2 ', async () => {
        
        //browser start
        start (validLogin,inValidPassword);
        
        // proper url
        await expect(browser).toHaveUrl(loginUrl);
        
        //check alert messages
        LoginPage.wrongLogin(); 
    })

    xit('Test case ID: 3 ', async () => {
        
        //browser start
        start (inValidLogin,validPassword);
        
        // proper url
        await expect(browser).toHaveUrl(loginUrl);
        
        //check alert messages
        LoginPage.wrongLogin();
    })

    xit('Test case ID: 4 ', async () => {
        
        //browser start
        start (validLogin,validPassword);
        
        // proper url
        await expect(browser).toHaveUrl(inventoryUrl);       
        
        //all elements displayed
        inventoryPage.inventoryPageIsDisplayedOK();

        //click on burgerbutton
        inventoryPage.burgerMenuGet();

        //burger menu displayed
        inventoryPage.burgerMenuDisplayedOk(); 

        //click logout button
        inventoryPage.logOut();
        
        //check if we back at login page
        await expect(browser).toHaveUrl(loginUrl);
        
        //check if input fiealds are empty
        await expect(LoginPage.loginPageEmpty());      
    })

    xit('Test case ID: 5 ', async () => {
        
        const item = 1;
        
        //browser start
        start (validLogin,validPassword);
        
        // proper url
        await expect(browser).toHaveUrl(inventoryUrl);       
        
        //all items displayed
        inventoryPage.inventoryPageIsDisplayedOK();

        //add item to cart
        inventoryPage.addToCart(item);

        //remember label of added item
        const productElement = await $('(//div[@class="inventory_item_name"])['+item+']');
        const innerText = await productElement.getText();
        
        //logout
        inventoryPage.burgerMenuGet();
        inventoryPage.burgerMenuDisplayedOk();
        inventoryPage.logOut();

        // check if input fields are empty
        await expect(LoginPage.loginPageEmpty());
       
        //login
        start (validLogin,validPassword);

        //all items displayed
        inventoryPage.inventoryPageIsDisplayedOK();

        //check if cart not empty
        await expect(inventoryPage.cartNotEmpty());

        //open cart
        inventoryPage.cartOpen();
        
        //check if cart displayed
        cartPage.cartDisplayedOk();

       //compare elements in cart with added 
       await expect(cartPage.compareItems(innerText));
    })

    it('Test case ID: 6 ', async () => {
        
        //browser start
        start (validLogin,validPassword);
        
        // proper url
        await expect(browser).toHaveUrl(inventoryUrl);

        //all items displayed
        inventoryPage.inventoryPageIsDisplayedOK();

        /*This loop making sorting elements by index 
        0 = A-Z
        1 = Z-A
        2 = Price: lo-hi
        3 = Price: hi-lo
        and check if sorts right */
        
        let sorted = false;
        for ( let i = 1; i <= 4; i++ )
        {
            sorted = await inventoryPage.sortAndCheckItems(i);
            if (sorted === false){
                throw new Error('Sort invalid!');
            }
        } 
    })
        
        xit('Test case ID: 7 ', async () => {
        
            //browser start
            start (validLogin,validPassword);
            
            // proper url
            await expect(browser).toHaveUrl(inventoryUrl);

            ///all items displayed OK
            inventoryPage.inventoryPageIsDisplayedOK();
            
            //scroll to footer
            await inventoryPage.scrollToFooter();
           
            //click on FB button
            await inventoryPage.facebookClick();

            //check if it opens correctly
            await inventoryPage.checkUrl(facebookUrl);

            //click on twitter button
            await inventoryPage.twitterClick();

            //check if it opens correctly
            await inventoryPage.checkUrl(twitterUrl);
            
            //click on linkedIn button
            await inventoryPage.linkedinClick();
            
            //check if it opens correctly
            await inventoryPage.checkUrl(linkedinUrl);
        })

        xit('Test case ID: 8 ', async () => {
            
            //index for added element. May be from 1 to 6, as elements on the page
            const item = 1;

            //browser start
            start (validLogin,validPassword);
            
            // proper url
            await expect(browser).toHaveUrl(inventoryUrl);

            //all items displayed OK
            inventoryPage.inventoryPageIsDisplayedOK();
            
            //add item to cart
            inventoryPage.addToCart(item);

            //check cart not empty
            expect(inventoryPage.cartNotEmpty());

            //remember label of added item
            const productElement = await $('(//div[@class="inventory_item_name"])['+item+']');
            const innerText = await productElement.getText();
            
            //open cart
            inventoryPage.cartOpen();
            
            //check if url match url in the cart
            await expect(browser).toHaveUrl(cartUrl);

            //check if cart displayed OK
            cartPage.cartDisplayedOk();

            //compare elements in cart with added 
            await expect(cartPage.compareItems(innerText));
                        
            //CheckOut button click
            cartPage.checkoutClick();
            
            //check checkout url
            await expect(browser).toHaveUrl(checkoutUrl);

            //checkout page displayed
            checkoutPage.checkoutIsDisplayedOk();

            //set credentials
            checkoutPage.setCheckoutCredentials('Johny', 'Bravo', '03189');
            
            //check confirmation page url
            await expect(browser).toHaveUrl(confirmationUrl);

            //confirmation page displayed OK
            confirmationPage.confirmationIsDisplayedOk();

            //click finish button
            confirmationPage.finishButtonClick();
            
            // check final url
            await expect(browser).toHaveUrl(finalUrl);

            //items on final page displayed OK
            finalPage.finalIsDisplayedOk();

            // Back button click
            finalPage.backButtonClick();

            //check if redirect to inventory page
            await expect(browser).toHaveUrl(inventoryUrl);

            //inventory page displayed OK
            expect(inventoryPage.inventoryPageIsDisplayedOK());
        })

        xit('Test case ID: 9 ', async () => {
            
            //browser start
            start (validLogin,validPassword);
            
            // proper url
            await expect(browser).toHaveUrl(inventoryUrl);
            
            //page displayed OK
            inventoryPage.inventoryPageIsDisplayedOK();
            
            //open cart
            inventoryPage.cartOpen();

            //check all elements in cart displayed
            cartPage.cartDisplayedOk();

            //click on chekout button
            cartPage.checkoutClick();

            //wait
            await browser.waitUntil(() => {return cartPage.footer.isDisplayed();},15000, 'something wrong!!!!');

            //check we stands in cart
            await expect(browser).toHaveUrl(cartUrl);
            /*
            This test case should fall because cart page
            have no handler for exceptions
            This happens even in manual test
            Also I could not find any error message container, 
            like on login page, or on '/checkout-step-one.html'
            */
        })
    })
